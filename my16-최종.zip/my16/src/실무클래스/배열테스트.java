package 실무클래스;

public class 배열테스트 {

	public static void main(String[] args) {
		int[] num = { 1, 2, 3 };
		num[3] = 4;
		System.out.println(num[3]);
		//배열은 크기 조정 불가능.
		//배열은 한 타입만 넣을 수 있음.
	}
}

