package 생성자;

public class 키보드사용 {

	public static void main(String[] args) {
		키보드 key1 = new 키보드(20000, 2);
		키보드 key2 = new 키보드(20000, "tg", 2);
		System.out.println(key1);
		System.out.println(key2);
	}

}
