package 인터페이스;

public interface Car {
	public abstract void 출발하다();
	public abstract void 멈추다();
}
