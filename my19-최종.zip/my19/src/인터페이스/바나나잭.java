package 인터페이스;

public class 바나나잭 implements 아이폰잭 {

	@Override
	public void 납작하게만들다() {
		System.out.println("검정색으로 납작하게 만들다.");
	}

	@Override
	public void 이센티로만들다() {
		System.out.println("짧은 줄로 이센트로 만들다.");
	}

}
