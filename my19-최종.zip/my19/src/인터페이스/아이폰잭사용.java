package 인터페이스;

public class 아이폰잭사용 {

	public static void main(String[] args) {
		애플잭 apple = new 애플잭();
		바나나잭 banana = new 바나나잭();
		apple.납작하게만들다();
		apple.이센티로만들다();
		banana.납작하게만들다();
		banana.이센티로만들다();
		
	}

}
