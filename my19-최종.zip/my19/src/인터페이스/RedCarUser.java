package 인터페이스;

public class RedCarUser {

	public static void main(String[] args) {
		Car car = new BlueCar();
		car.출발하다();
		car.멈추다();
	}

}
