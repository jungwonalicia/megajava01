package 인터페이스;

public interface 아이폰잭 {
	//불완전한 메소드
	//구체적이지 않고 추상적인 abstract!
	//추상 메소드 = abstract method!
	//(public abstract)
	//일반 변수 사용 불가
	void 납작하게만들다();
	public abstract void 이센티로만들다();
}
