package 인터페이스;

public class 애플잭 implements 아이폰잭 {

	@Override
	public void 납작하게만들다() {
		System.out.println("흰색으로 납작하게 만들다.");
	}

	@Override
	public void 이센티로만들다() {
		System.out.println("긴줄을 사용하여 이센티로 만들다.");
	}

}
