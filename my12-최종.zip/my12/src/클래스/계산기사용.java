package 클래스;

public class 계산기사용 {

	public static void main(String[] args) {
		계산기 cal = new 계산기();
		cal.add();
		int result = cal.add(200, 100);
		System.out.println(cal.add(200,100));
		//System.out.println(cal.add());
		//void타입의 메소드를 호출한 경우에는
		//반환값이 없으므로 변수에 값을 넣을 수 도 없고
		//프린트할 수도 없음.
		
		
		
		
		
		
		
	}

}
