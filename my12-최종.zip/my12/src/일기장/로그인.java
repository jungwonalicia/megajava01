package 일기장;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class 로그인 {
	private static JTextField t1;
	private static JTextField t2;

	public static void main(String[] args) {
		JFrame f = new JFrame("나의 로그인");
		f.getContentPane().setBackground(Color.GREEN);
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("D:\\limjw\\my12\\main.png"));
		lblNewLabel.setBounds(105, 34, 263, 191);
		f.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("아이디:");
		lblNewLabel_1.setFont(new Font("굴림", Font.BOLD, 20));
		lblNewLabel_1.setBounds(99, 255, 82, 39);
		f.getContentPane().add(lblNewLabel_1);
		
		JLabel label = new JLabel("비밀번호:");
		label.setFont(new Font("굴림", Font.BOLD, 20));
		label.setBounds(99, 309, 99, 39);
		f.getContentPane().add(label);
		
		t1 = new JTextField();
		t1.setForeground(Color.RED);
		t1.setFont(new Font("굴림", Font.BOLD, 30));
		t1.setBounds(218, 251, 166, 39);
		f.getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		t2.setForeground(Color.RED);
		t2.setFont(new Font("굴림", Font.BOLD, 30));
		t2.setColumns(10);
		t2.setBounds(218, 309, 166, 39);
		f.getContentPane().add(t2);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = t1.getText();
				String pw = t2.getText();
				if (id.equals("root") && pw.equals("1234")) {
					//일기쓰러 감. => diary()필요
					일기쓰기 today = new 일기쓰기();
					today.diary();
					//diary()메소드를 쓰고 싶으면,
					//이 메소드를 쓸 수 있는 주소를 가진 변수만 있으면 된다.
				} else {
					//경고메시지
					JOptionPane.showMessageDialog(null, "id, pw입력이 잘못되었습니다.");
				}
				
			}
		});
		btnNewButton.setIcon(new ImageIcon("D:\\limjw\\my12\\check.png"));
		btnNewButton.setBounds(68, 377, 152, 125);
		f.getContentPane().add(btnNewButton);
		
		JButton button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//id, pw를 공백으로 초기화
				t1.setText("");
				t2.setText("");
			}
		});
		button.setIcon(new ImageIcon("D:\\limjw\\my12\\reset.png"));
		button.setBounds(257, 377, 152, 125);
		f.getContentPane().add(button);
		f.setSize(487, 551);
		f.setVisible(true);
	}
}




