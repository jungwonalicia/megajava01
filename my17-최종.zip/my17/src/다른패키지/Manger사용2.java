package 다른패키지;

import 상속.Manager;

public class Manger사용2 {

	public static void main(String[] args) {
		Manager m2 = new Manager();
		m2.name = "김길동";
	}
}
