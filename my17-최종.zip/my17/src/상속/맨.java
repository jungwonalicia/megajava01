package 상속;

public class 맨 extends 사람{ //상속=재사용
	int power;
	
	public void 달리다() {
		System.out.println("빨리 달리다.");
	}
}
