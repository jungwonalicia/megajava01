package 상속;

public class Tv사용 {

	public static void main(String[] args) {
		Tv tv = new Tv("빨강", 50);
		System.out.println(tv);
		tv.on();
	}

}
