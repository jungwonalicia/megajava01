package 상속;

public class Manager extends Employee {
	private int bonus = 1000;
	
	public void test() {
		System.out.println("관리 감독하다.");
	}
	
}
