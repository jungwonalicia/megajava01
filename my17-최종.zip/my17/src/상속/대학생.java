package 상속;

public class 대학생 extends 학생 {
	
	@Override //재정의
	public void 배우다() {
		System.out.println("취업공부를 하다.");
	}
}
