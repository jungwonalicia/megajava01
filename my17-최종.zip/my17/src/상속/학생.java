package 상속;

public class 학생 {
	public void 배우다() {
		System.out.println("무엇인가를 배우다.");
	}
}
