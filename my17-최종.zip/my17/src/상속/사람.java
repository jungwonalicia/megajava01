package 상속;

public class 사람 {
	String gender;
	String name;
	
	public void 잠자다() {
		System.out.println("잠을 자다.");
	}
	public void 먹다() {
		System.out.println("음식을 먹다.");
	}
}
