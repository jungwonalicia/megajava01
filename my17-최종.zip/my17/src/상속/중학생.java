package 상속;

public class 중학생 extends 학생 {
	
	@Override //재정의
	public void 배우다() {
		System.out.println("영어단어를 외우다.");
	}
}
