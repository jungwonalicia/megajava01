package 일기장;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class 로그인 {
	private static JTextField t1;
	private static JTextField t2;

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.GREEN);
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("D:\\limjw\\my12\\main.png"));
		lblNewLabel.setBounds(105, 34, 263, 191);
		f.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("아이디:");
		lblNewLabel_1.setFont(new Font("굴림", Font.BOLD, 20));
		lblNewLabel_1.setBounds(99, 255, 82, 39);
		f.getContentPane().add(lblNewLabel_1);
		
		JLabel label = new JLabel("비밀번호:");
		label.setFont(new Font("굴림", Font.BOLD, 20));
		label.setBounds(99, 309, 99, 39);
		f.getContentPane().add(label);
		
		t1 = new JTextField();
		t1.setForeground(Color.RED);
		t1.setFont(new Font("굴림", Font.BOLD, 30));
		t1.setBounds(218, 251, 166, 39);
		f.getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		t2.setForeground(Color.RED);
		t2.setFont(new Font("굴림", Font.BOLD, 30));
		t2.setColumns(10);
		t2.setBounds(218, 309, 166, 39);
		f.getContentPane().add(t2);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon("D:\\limjw\\my12\\check.png"));
		btnNewButton.setBounds(68, 377, 152, 125);
		f.getContentPane().add(btnNewButton);
		
		JButton button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//id, pw를 공백으로 초기화
				t1.setText("");
				t2.setText("");
			}
		});
		button.setIcon(new ImageIcon("D:\\limjw\\my12\\reset.png"));
		button.setBounds(257, 377, 152, 125);
		f.getContentPane().add(button);
		f.setTitle("나의 일기장");
		f.setSize(487, 551);
		f.setVisible(true);
	}
}




